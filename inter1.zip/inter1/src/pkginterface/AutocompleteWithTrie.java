package pkginterface;
import java.net.*;
 import java.io.*;
import java.util.LinkedList;
import java.util.List;
import java.util.ArrayList;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.Scanner;
class TrieNode {
    char data;     
    LinkedList<TrieNode> children; //builtin linkedlist class
    TrieNode parent;
    boolean isEnd;
 
    public TrieNode(char c) {//constructor initializes a node by data that was passed 
        //a children named linkdlist if trie node
    	data = c;
        children = new LinkedList<TrieNode>();//object of linked list
        isEnd = false;        
    }  
    //root is emoty string
    public TrieNode getChild(char c) {//returns child nodeby searching the trie node
        if (children != null)
            for (TrieNode eachChild : children)
           /*Instead of declaring and initializing a loop counter variable, you declare a variable that 
                is the same type as the base type of the array, followed by a colon, 
                which is then followed by the array name
                
                In the loop body, you can use the loop variable you created 
                rather than using an indexed array element.*/
            //It’s commonly used to iterate over an array or a Collections class (eg, ArrayList)
                if (eachChild.data == c)
                    return eachChild;
        return null;
    }
    
    protected List<String> getWords() {//returns list of strings associated with this trienode
       List<String> list = new ArrayList<String>(); //object of arraylist is made      
       if (isEnd) {
    	   list.add(toString());//string representation of the object list is called
       }
       //PREORDER TRAVERSAL
       if (children != null) {
	       for (int i=0; i< children.size(); i++) {
	          if (children.get(i) != null) {
	             list.addAll(children.get(i).getWords());
                     //The get method is used to obtain or retrieve a particular variable value from a class.
	          }
	       }
       }       
       return list; 
    }
    
	public String toString() {
		if (parent == null) {
		     return "";
		} else {
		     return parent.toString() + new String(new char[] {data});
		}
	}
}
 
class Trie {
    private TrieNode root;
 
    public Trie() {
        root = new TrieNode(' '); 
    }
 
    public void insert(String word) {
        if (search(word) == true) 
            return;    
        
        TrieNode current = root; 
        TrieNode pre ;
        for (char ch : word.toCharArray()) {
        	pre = current;
            TrieNode child = current.getChild(ch);
            if (child != null) {
                current = child;
                child.parent = pre;
            } else {
                 current.children.add(new TrieNode(ch));
                 current = current.getChild(ch);
                 current.parent = pre;
            }
        }
        current.isEnd = true;
    }
    
    public boolean search(String word) {
        TrieNode current = root;      
        for (char ch : word.toCharArray()) {
            if (current.getChild(ch) == null)
                return false;
            else {
                current = current.getChild(ch);    
            }
        }      
        if (current.isEnd == true) {       
            return true;
        }
        return false;
    }
    
    public List<String> autocomplete(String prefix) {     
       TrieNode lastNode = root;
       for (int i = 0; i< prefix.length(); i++) {
	       lastNode = lastNode.getChild(prefix.charAt(i));	     
	       if (lastNode == null) 
	    	   return new ArrayList<String>();      
       }
       
       return lastNode.getWords();
    }
    
    
}    

public class AutocompleteWithTrie {
	 public static void main(String[] args) throws IOException,Exception {            
            Trie t = new Trie();            
            t.insert("amazon"); 
            t.insert("amazon prime"); 
			t.insert("amazing"); 			 
            t.insert("amazing spider man"); 
            t.insert("amazed");
            t.insert("alibaba");
            t.insert("ali express");
            t.insert("ebay");
            t.insert("walmart"); 
            //t.insert("joudet");
            t.insert("joude");
             URL oracle = new URL("http://wiki.puzzlers.org/pub/wordlists/web2.txt");
    BufferedReader in = new BufferedReader(
    new InputStreamReader(oracle.openStream()));

    String inputLine;
    while ((inputLine = in.readLine()) != null)
       // System.out.println(inputLine);
        t.insert(inputLine);
    in.close();
          /*  BufferedReader br = null;
            try{
                br = new BufferedReader(new FileReader("words_alpha.txt"));
                String line;
                while((line=br.readLine())!=null)
                {
                   // System.out.println(line);
                    
                }
            }
            catch(IOException o){
                
            }
            finally{
            br.close();
            
            }*/
            Scanner abc = new Scanner(System.in);
           String x = abc.nextLine();
            
				List<String> a= t.autocomplete(x);
                String[] Array = new String[a.size()];         
                        
			for (int i = 0; i < a.size(); i++) {
				//System.out.println();
                                Array[i]=a.get(i);
			}
                        
                        for(String ab: Array){
                            System.out.println(ab);
                        }
                        
	  }
}


