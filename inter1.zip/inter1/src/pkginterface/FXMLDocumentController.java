/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkginterface;
//package pkginterface;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import org.controlsfx.control.textfield.TextFields;

class test{
    public HashMap<String,String> hp;
  
    
   
   test(){
     hp = new HashMap<>();   
       hp.put("green", "color");
       hp.put("minahil", "pagal a pagal");
        String fullfilepath;
        fullfilepath = "C:\\Users\\joude\\OneDrive\\Documents\\NetBeansProjects\\inter\\src\\beingzero_dictionary.csv";
    String line;
    try{
        BufferedReader br = new BufferedReader(new FileReader(fullfilepath));
        while((line=br.readLine())!=null){
        String parts[]=line.split("===");
        hp.put(parts[0].trim().toLowerCase(), parts[1]);
            
                }
    }
    catch(IOException ex){
        ex.printStackTrace();
    }
   }
  
}


public class FXMLDocumentController implements Initializable {
   //@FXML private TextField tittel; 
    
    
   @FXML
   private AnchorPane root;
   @FXML
   private  TextField input;
   //AutocompleteWithTrie tree = new AutocompleteWithTrie();
     AutocompleteWithTrie tree = new AutocompleteWithTrie();
  Trie tree1 = new Trie();
    @FXML
    private ImageView imageveiw;
    @FXML
    private Button button;
    @FXML
    private TextArea meaning;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      URL oracle;
       try {
           oracle = new URL("http://wiki.puzzlers.org/pub/wordlists/web2.txt");
       
    BufferedReader in = new BufferedReader(
    new InputStreamReader(oracle.openStream()));

    String inputLine;
    while ((inputLine = in.readLine()) != null)
       // System.out.println(inputLine);
        tree1.insert(inputLine);
    in.close();
    
    }   catch (MalformedURLException ex) {
           Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
       } catch (IOException ex) {
           Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
       }  
    }  
       
        
        //List<String> a= tree.autocomplete("b");
        
//String[] words ={"kinza","kusar","kinnu","joudet","javeria","jawad","jamal","kianat","kiran","kanwal","amar","ali"};
    @FXML
    private void auto(KeyEvent event) {
        
          
        
    
        
    }

    @FXML
    private void auto2(KeyEvent event) {
    
    
}

    @FXML
    private void auto3(KeyEvent event){ 
           // tree1.insert("abcs");
      String text=input.getText().toString();	
     //System.out.println(text);
       List<String> a= tree1.autocomplete(text);
       // System.out.println(a.get(1));
       String[] Array = new String[a.size()]; 
       
      //  System.out.println(Array[0]);
   for (int i = 0; i < a.size(); i++) {
	 Array[i]=a.get(i);			//System.out.println();
                          
      }
       
 TextFields.bindAutoCompletion(input,Array);
       //TextFields.bindAutoCompletion(input, );

            
        
        
        
    }

    @FXML
    private void onclick(MouseEvent event) {
      String abc = input.getText().toLowerCase();
     
      test abcd = new test();
    String mean =  abcd.hp.get(abc);
     meaning.setText(mean);
     
    }


    
}